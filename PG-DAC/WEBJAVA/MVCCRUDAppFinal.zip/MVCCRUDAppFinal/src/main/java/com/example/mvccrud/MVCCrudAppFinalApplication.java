package com.example.mvccrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MVCCrudAppFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(MVCCrudAppFinalApplication.class, args);
	}

}
