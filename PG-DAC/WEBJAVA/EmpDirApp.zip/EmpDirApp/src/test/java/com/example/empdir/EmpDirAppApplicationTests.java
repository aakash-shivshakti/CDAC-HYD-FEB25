package com.example.empdir;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpDirAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
