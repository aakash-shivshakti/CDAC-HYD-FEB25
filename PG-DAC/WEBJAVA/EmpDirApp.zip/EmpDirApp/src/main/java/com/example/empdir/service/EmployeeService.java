package com.example.empdir.service;

import java.util.List;

import com.example.empdir.entity.Employee;

public interface EmployeeService {

	public List<Employee> findAllEmp();  // 1 get all employees
	
	
}
